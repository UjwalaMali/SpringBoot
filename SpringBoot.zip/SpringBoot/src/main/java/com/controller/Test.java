package com.controller;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Student.Student;

@RestController
@CrossOrigin("http://localhost:4200")
public class Test {

	@Autowired
	SessionFactory factory;
	
	@PostMapping("saveStudent")
	public ResponseEntity<Student> saveStudent( @RequestBody Student student) {
	
		System.out.println(student);
		
		Session session = factory.openSession();
		
		Transaction tx=session.beginTransaction();
		
		session.save(student);
		
		tx.commit();
		ResponseEntity<Student> responseEntity= new ResponseEntity<>(student,HttpStatus.OK);
		
			return responseEntity ;
	}
	
	
	@PutMapping("updateStudent")
	public ResponseEntity<Student> updateStudent(@RequestBody Student student) {
		
		System.out.println(student);
		
		Session session=factory.openSession();
		
		Transaction tx=session.beginTransaction();
		
		session.update(student);
		
		tx.commit();
		
        ResponseEntity<Student> responseEntity= new ResponseEntity<>(student,HttpStatus.OK);
		
		return responseEntity;
	}
	
	@GetMapping("getStudent/{id}")
	public ResponseEntity<Student> getStudent( @PathVariable int id) {
		
	Session session=factory.openSession();
	
	Student student=session.get(Student.class,id);
	
	ResponseEntity<Student> responseEntity= new ResponseEntity<>(student,HttpStatus.OK);
		
		return responseEntity;
		
	}
	
	@DeleteMapping("deleteStudent/{id}")
	public ResponseEntity<Student> deleteStudent(@PathVariable int id) {
		
		Session session=factory.openSession();
		
		Student student=session.get(Student.class,id);
		
		Transaction tx=session.beginTransaction();
		
		session.delete(student);
		
		tx.commit();
		
		ResponseEntity<Student> responseEntity= new ResponseEntity<>(student,HttpStatus.OK);
		
		return responseEntity;
	}
	
	@RequestMapping("getAllemployee")
	List<Student> getAllemployee(){
		
		Session session =factory.openSession();
		
		Criteria cr=session.createCriteria(Student.class);
		
		List<Student> list=cr.list();
		
		return list;
		
	}
	
	@PostMapping("saveMultiplestudent")
	public void saveMultiplestudent(@RequestBody Student[] students) {
		Session session=factory.openSession();
		
		for (Student student : students) {
			Transaction tx=session.beginTransaction();
			
	        session.save(student);
	        
	        tx.commit();
		}
	}
	}
